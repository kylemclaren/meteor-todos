(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var PublicationCollector;

var require = meteorInstall({"node_modules":{"meteor":{"publication-collector":{"publication-collector.js":["babel-runtime/helpers/toConsumableArray",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/publication-collector/publication-collector.js                                                      //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                   //
                                                                                                                //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                          //
                                                                                                                //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }               //
                                                                                                                //
/* global PublicationCollector:true */                                                                          //
                                                                                                                //
var EventEmitter = Npm.require("events").EventEmitter;                                                          // 3
                                                                                                                //
// This file describes something like Subscription in                                                           //
// meteor/meteor/packages/ddp/livedata_server.js, but instead of sending                                        //
// over a socket it just collects data                                                                          //
PublicationCollector = function PublicationCollector() {                                                        // 8
  var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];                        //
                                                                                                                //
  // Object where the keys are collection names, and then the keys are _ids                                     //
  this.responseData = {};                                                                                       // 10
                                                                                                                //
  this.userId = options.userId;                                                                                 // 12
};                                                                                                              //
                                                                                                                //
// So that we can listen to ready event in a reasonable way                                                     //
Meteor._inherits(PublicationCollector, EventEmitter);                                                           // 16
                                                                                                                //
_.extend(PublicationCollector.prototype, {                                                                      // 18
  collect: function () {                                                                                        // 19
    function collect(name) {                                                                                    //
      var _this = this;                                                                                         //
                                                                                                                //
      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];                                                                       //
      }                                                                                                         //
                                                                                                                //
      if (_.isFunction(args[args.length - 1])) {                                                                // 20
        this.on('ready', args.pop());                                                                           // 21
      }                                                                                                         //
                                                                                                                //
      var handler = Meteor.server.publish_handlers[name];                                                       // 24
      var result = handler.call.apply(handler, [this].concat((0, _toConsumableArray3["default"])(args)));       // 25
                                                                                                                //
      // TODO -- we should check that result has _publishCursor? What does _runHandler do?                      //
      if (result) {                                                                                             // 19
        // array-ize                                                                                            //
        [].concat(result).forEach(function (cur) {                                                              // 30
          return cur._publishCursor(_this);                                                                     //
        });                                                                                                     //
        this.ready();                                                                                           // 31
      }                                                                                                         //
    }                                                                                                           //
                                                                                                                //
    return collect;                                                                                             //
  }(),                                                                                                          //
  added: function () {                                                                                          // 34
    function added(collection, id, fields) {                                                                    //
      check(collection, String);                                                                                // 35
      check(id, String);                                                                                        // 36
                                                                                                                //
      this._ensureCollectionInRes(collection);                                                                  // 38
                                                                                                                //
      // Make sure to ignore the _id in fields                                                                  //
      var addedDocument = _.extend({ _id: id }, _.omit(fields, "_id"));                                         // 34
      this.responseData[collection][id] = addedDocument;                                                        // 42
    }                                                                                                           //
                                                                                                                //
    return added;                                                                                               //
  }(),                                                                                                          //
  changed: function () {                                                                                        // 44
    function changed(collection, id, fields) {                                                                  //
      check(collection, String);                                                                                // 45
      check(id, String);                                                                                        // 46
                                                                                                                //
      this._ensureCollectionInRes(collection);                                                                  // 48
                                                                                                                //
      var existingDocument = this.responseData[collection][id];                                                 // 50
      var fieldsNoId = _.omit(fields, "_id");                                                                   // 51
      _.extend(existingDocument, fieldsNoId);                                                                   // 52
                                                                                                                //
      // Delete all keys that were undefined in fields (except _id)                                             //
      _.forEach(fields, function (value, key) {                                                                 // 44
        if (value === undefined) {                                                                              // 56
          delete existingDocument[key];                                                                         // 57
        }                                                                                                       //
      });                                                                                                       //
    }                                                                                                           //
                                                                                                                //
    return changed;                                                                                             //
  }(),                                                                                                          //
  removed: function () {                                                                                        // 61
    function removed(collection, id) {                                                                          //
      check(collection, String);                                                                                // 62
      check(id, String);                                                                                        // 63
                                                                                                                //
      this._ensureCollectionInRes(collection);                                                                  // 65
                                                                                                                //
      delete this.responseData[collection][id];                                                                 // 67
                                                                                                                //
      if (_.isEmpty(this.responseData[collection])) {                                                           // 69
        delete this.responseData[collection];                                                                   // 70
      }                                                                                                         //
    }                                                                                                           //
                                                                                                                //
    return removed;                                                                                             //
  }(),                                                                                                          //
  ready: function () {                                                                                          // 73
    function ready() {                                                                                          //
      this.emit('ready', this._generateResponse());                                                             // 74
    }                                                                                                           //
                                                                                                                //
    return ready;                                                                                               //
  }(),                                                                                                          //
  onStop: function () {                                                                                         // 76
    function onStop() {                                                                                         //
      // no-op in HTTP                                                                                          //
    }                                                                                                           //
                                                                                                                //
    return onStop;                                                                                              //
  }(),                                                                                                          //
  error: function () {                                                                                          // 79
    function error(_error) {                                                                                    //
      throw _error;                                                                                             // 80
    }                                                                                                           //
                                                                                                                //
    return error;                                                                                               //
  }(),                                                                                                          //
  _ensureCollectionInRes: function () {                                                                         // 82
    function _ensureCollectionInRes(collection) {                                                               //
      this.responseData[collection] = this.responseData[collection] || {};                                      // 83
    }                                                                                                           //
                                                                                                                //
    return _ensureCollectionInRes;                                                                              //
  }(),                                                                                                          //
  _generateResponse: function () {                                                                              // 85
    function _generateResponse() {                                                                              //
      var output = {};                                                                                          // 86
                                                                                                                //
      _.forEach(this.responseData, function (documents, collectionName) {                                       // 88
        output[collectionName] = _.values(documents);                                                           // 89
      });                                                                                                       //
                                                                                                                //
      return output;                                                                                            // 92
    }                                                                                                           //
                                                                                                                //
    return _generateResponse;                                                                                   //
  }()                                                                                                           //
});                                                                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/publication-collector/publication-collector.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['publication-collector'] = {}, {
  PublicationCollector: PublicationCollector
});

})();

//# sourceMappingURL=publication-collector.js.map
