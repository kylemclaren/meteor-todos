(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var ValidatedMethod;

var require = meteorInstall({"node_modules":{"meteor":{"mdg:validated-method":{"validated-method.js":["babel-runtime/helpers/classCallCheck",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/mdg_validated-method/validated-method.js                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                        //
                                                                                                               //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                               //
                                                                                                               //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }              //
                                                                                                               //
/* global ValidatedMethod:true */                                                                              //
                                                                                                               //
ValidatedMethod = function () {                                                                                // 3
  function ValidatedMethod(options) {                                                                          // 4
    var _connection$methods;                                                                                   //
                                                                                                               //
    (0, _classCallCheck3['default'])(this, ValidatedMethod);                                                   //
                                                                                                               //
    // Default to no mixins                                                                                    //
    options.mixins = options.mixins || [];                                                                     // 6
    check(options.mixins, [Function]);                                                                         // 7
    check(options.name, String);                                                                               // 8
    options = applyMixins(options, options.mixins);                                                            // 9
                                                                                                               //
    // connection argument defaults to Meteor, which is where Methods are defined on client and                //
    // server                                                                                                  //
    options.connection = options.connection || Meteor;                                                         // 4
                                                                                                               //
    // Allow validate: null shorthand for methods that take no arguments                                       //
    if (options.validate === null) {                                                                           // 4
      options.validate = function () {};                                                                       // 17
    }                                                                                                          //
                                                                                                               //
    check(options, Match.ObjectIncluding({                                                                     // 20
      name: String,                                                                                            // 21
      validate: Function,                                                                                      // 22
      run: Function,                                                                                           // 23
      mixins: [Function],                                                                                      // 24
      connection: Object                                                                                       // 25
    }));                                                                                                       //
                                                                                                               //
    _.extend(this, options);                                                                                   // 28
                                                                                                               //
    var method = this;                                                                                         // 30
    this.connection.methods((_connection$methods = {}, _connection$methods[options.name] = function (args) {   // 31
      // Silence audit-argument-checks since arguments are always checked when using this package              //
      check(args, Match.Any);                                                                                  // 34
      var methodInvocation = this;                                                                             // 35
                                                                                                               //
      return method._execute(methodInvocation, args);                                                          // 37
    }, _connection$methods));                                                                                  //
  }                                                                                                            //
                                                                                                               //
  ValidatedMethod.prototype.call = function () {                                                               // 3
    function call(args, callback) {                                                                            //
      // Accept calling with just a callback                                                                   //
      if (_.isFunction(args)) {                                                                                // 44
        callback = args;                                                                                       // 45
        args = {};                                                                                             // 46
      }                                                                                                        //
                                                                                                               //
      var options = {                                                                                          // 49
        // Make it possible to get the ID of an inserted item                                                  //
        returnStubValue: true,                                                                                 // 51
                                                                                                               //
        // Don't call the server method if the client stub throws an error, so that we don't end               //
        // up doing validations twice                                                                          //
        // XXX needs option to disable, in cases where the client might have incomplete information to         //
        // make a decision                                                                                     //
        throwStubExceptions: true                                                                              // 57
      };                                                                                                       //
                                                                                                               //
      try {                                                                                                    // 60
        return this.connection.apply(this.name, [args], options, callback);                                    // 61
      } catch (err) {                                                                                          //
        if (callback) {                                                                                        // 63
          // Get errors from the stub in the same way as from the server-side method                           //
          callback(err);                                                                                       // 65
        } else {                                                                                               //
          // No callback passed, throw instead of silently failing; this is what                               //
          // "normal" Methods do if you don't pass a callback.                                                 //
          throw err;                                                                                           // 69
        }                                                                                                      //
      }                                                                                                        //
    }                                                                                                          //
                                                                                                               //
    return call;                                                                                               //
  }();                                                                                                         //
                                                                                                               //
  ValidatedMethod.prototype._execute = function () {                                                           // 3
    function _execute(methodInvocation, args) {                                                                //
      methodInvocation = methodInvocation || {};                                                               // 75
                                                                                                               //
      // Add `this.name` to reference the Method name                                                          //
      methodInvocation.name = this.name;                                                                       // 74
                                                                                                               //
      var validateResult = this.validate.bind(methodInvocation)(args);                                         // 80
                                                                                                               //
      if (typeof validateResult !== 'undefined') {                                                             // 82
        throw new Error('Returning from validate doesn\'t do anything; perhaps you meant to throw an error?');
      }                                                                                                        //
                                                                                                               //
      return this.run.bind(methodInvocation)(args);                                                            // 87
    }                                                                                                          //
                                                                                                               //
    return _execute;                                                                                           //
  }();                                                                                                         //
                                                                                                               //
  return ValidatedMethod;                                                                                      //
}();                                                                                                           //
                                                                                                               //
// Mixins get a chance to transform the arguments before they are passed to the actual Method                  //
function applyMixins(args, mixins) {                                                                           // 92
  // You can pass nested arrays so that people can ship mixin packs                                            //
  var flatMixins = _.flatten(mixins);                                                                          // 94
  // Save name of the method here, so we can attach it to potential error messages                             //
  var _args = args;                                                                                            // 92
  var name = _args.name;                                                                                       //
                                                                                                               //
                                                                                                               //
  flatMixins.forEach(function (mixin) {                                                                        // 98
    args = mixin(args);                                                                                        // 99
                                                                                                               //
    if (!Match.test(args, Object)) {                                                                           // 101
      var functionName = mixin.toString().match(/function\s(\w+)/);                                            // 102
      var msg = 'One of the mixins';                                                                           // 103
                                                                                                               //
      if (functionName) {                                                                                      // 105
        msg = 'The function \'' + functionName[1] + '\'';                                                      // 106
      }                                                                                                        //
                                                                                                               //
      throw new Error('Error in ' + name + ' method: ' + msg + ' didn\'t return the options object.');         // 109
    }                                                                                                          //
  });                                                                                                          //
                                                                                                               //
  return args;                                                                                                 // 113
}                                                                                                              //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/mdg:validated-method/validated-method.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['mdg:validated-method'] = {}, {
  ValidatedMethod: ValidatedMethod
});

})();

//# sourceMappingURL=mdg_validated-method.js.map
