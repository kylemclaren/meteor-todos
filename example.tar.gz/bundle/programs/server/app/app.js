var require = meteorInstall({"imports":{"api":{"lists":{"server":{"publications.js":["meteor/meteor","../lists.js",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/lists/server/publications.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 3
                                                                                                                     //
var _lists = require('../lists.js');                                                                                 // 5
                                                                                                                     //
/* eslint-disable prefer-arrow-callback */                                                                           //
                                                                                                                     //
_meteor.Meteor.publish('lists.public', function () {                                                                 // 7
  function listsPublic() {                                                                                           // 7
    return _lists.Lists.find({                                                                                       // 8
      userId: { $exists: false }                                                                                     // 9
    }, {                                                                                                             //
      fields: _lists.Lists.publicFields                                                                              // 11
    });                                                                                                              //
  }                                                                                                                  //
                                                                                                                     //
  return listsPublic;                                                                                                //
}());                                                                                                                //
                                                                                                                     //
_meteor.Meteor.publish('lists.private', function () {                                                                // 15
  function listsPrivate() {                                                                                          // 15
    if (!this.userId) {                                                                                              // 16
      return this.ready();                                                                                           // 17
    }                                                                                                                //
                                                                                                                     //
    return _lists.Lists.find({                                                                                       // 20
      userId: this.userId                                                                                            // 21
    }, {                                                                                                             //
      fields: _lists.Lists.publicFields                                                                              // 23
    });                                                                                                              //
  }                                                                                                                  //
                                                                                                                     //
  return listsPrivate;                                                                                               //
}());                                                                                                                //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"lists.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/aldeed:simple-schema","meteor/factory","../todos/todos.js",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/lists/lists.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
exports.Lists = undefined;                                                                                           //
                                                                                                                     //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                              //
                                                                                                                     //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                     //
                                                                                                                     //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                        //
                                                                                                                     //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                               //
                                                                                                                     //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                          //
                                                                                                                     //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                 //
                                                                                                                     //
var _mongo = require('meteor/mongo');                                                                                // 1
                                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                    // 2
                                                                                                                     //
var _factory = require('meteor/factory');                                                                            // 3
                                                                                                                     //
var _todos = require('../todos/todos.js');                                                                           // 4
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                    //
                                                                                                                     //
var ListsCollection = function (_Mongo$Collection) {                                                                 //
  (0, _inherits3['default'])(ListsCollection, _Mongo$Collection);                                                    //
                                                                                                                     //
  function ListsCollection() {                                                                                       //
    (0, _classCallCheck3['default'])(this, ListsCollection);                                                         //
    return (0, _possibleConstructorReturn3['default'])(this, _Mongo$Collection.apply(this, arguments));              //
  }                                                                                                                  //
                                                                                                                     //
  ListsCollection.prototype.insert = function () {                                                                   //
    function insert(list, callback) {                                                                                //
      var ourList = list;                                                                                            // 8
      if (!ourList.name) {                                                                                           // 9
        var nextLetter = 'A';                                                                                        // 10
        ourList.name = 'List ' + nextLetter;                                                                         // 11
                                                                                                                     //
        while (!!this.findOne({ name: ourList.name })) {                                                             // 13
          // not going to be too smart here, can go past Z                                                           //
          nextLetter = String.fromCharCode(nextLetter.charCodeAt(0) + 1);                                            // 15
          ourList.name = 'List ' + nextLetter;                                                                       // 16
        }                                                                                                            //
      }                                                                                                              //
                                                                                                                     //
      return _Mongo$Collection.prototype.insert.call(this, ourList, callback);                                       // 20
    }                                                                                                                //
                                                                                                                     //
    return insert;                                                                                                   //
  }();                                                                                                               //
                                                                                                                     //
  ListsCollection.prototype.remove = function () {                                                                   // 6
    function remove(selector, callback) {                                                                            //
      _todos.Todos.remove({ listId: selector });                                                                     // 23
      return _Mongo$Collection.prototype.remove.call(this, selector, callback);                                      // 24
    }                                                                                                                //
                                                                                                                     //
    return remove;                                                                                                   //
  }();                                                                                                               //
                                                                                                                     //
  return ListsCollection;                                                                                            //
}(_mongo.Mongo.Collection);                                                                                          //
                                                                                                                     //
var Lists = exports.Lists = new ListsCollection('Lists');                                                            // 28
                                                                                                                     //
// Deny all client-side updates since we will be using methods to manage this collection                             //
Lists.deny({                                                                                                         // 31
  insert: function () {                                                                                              // 32
    function insert() {                                                                                              //
      return true;                                                                                                   // 32
    }                                                                                                                //
                                                                                                                     //
    return insert;                                                                                                   //
  }(),                                                                                                               //
  update: function () {                                                                                              // 33
    function update() {                                                                                              //
      return true;                                                                                                   // 33
    }                                                                                                                //
                                                                                                                     //
    return update;                                                                                                   //
  }(),                                                                                                               //
  remove: function () {                                                                                              // 34
    function remove() {                                                                                              //
      return true;                                                                                                   // 34
    }                                                                                                                //
                                                                                                                     //
    return remove;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Lists.schema = new _aldeedSimpleSchema.SimpleSchema({                                                                // 37
  name: { type: String },                                                                                            // 38
  incompleteCount: { type: Number, defaultValue: 0 },                                                                // 39
  userId: { type: String, regEx: _aldeedSimpleSchema.SimpleSchema.RegEx.Id, optional: true }                         // 40
});                                                                                                                  //
                                                                                                                     //
Lists.attachSchema(Lists.schema);                                                                                    // 43
                                                                                                                     //
// This represents the keys from Lists objects that should be published                                              //
// to the client. If we add secret properties to List objects, don't list                                            //
// them here to keep them private to the server.                                                                     //
Lists.publicFields = {                                                                                               // 48
  name: 1,                                                                                                           // 49
  incompleteCount: 1,                                                                                                // 50
  userId: 1                                                                                                          // 51
};                                                                                                                   //
                                                                                                                     //
_factory.Factory.define('list', Lists, {});                                                                          // 54
                                                                                                                     //
Lists.helpers({                                                                                                      // 56
  // A list is considered to be private if it has a userId set                                                       //
                                                                                                                     //
  isPrivate: function () {                                                                                           // 58
    function isPrivate() {                                                                                           //
      return !!this.userId;                                                                                          // 59
    }                                                                                                                //
                                                                                                                     //
    return isPrivate;                                                                                                //
  }(),                                                                                                               //
  isLastPublicList: function () {                                                                                    // 61
    function isLastPublicList() {                                                                                    //
      var publicListCount = Lists.find({ userId: { $exists: false } }).count();                                      // 62
      return !this.isPrivate() && publicListCount === 1;                                                             // 63
    }                                                                                                                //
                                                                                                                     //
    return isLastPublicList;                                                                                         //
  }(),                                                                                                               //
  editableBy: function () {                                                                                          // 65
    function editableBy(userId) {                                                                                    //
      if (!this.userId) {                                                                                            // 66
        return true;                                                                                                 // 67
      }                                                                                                              //
                                                                                                                     //
      return this.userId === userId;                                                                                 // 70
    }                                                                                                                //
                                                                                                                     //
    return editableBy;                                                                                               //
  }(),                                                                                                               //
  todos: function () {                                                                                               // 72
    function todos() {                                                                                               //
      return _todos.Todos.find({ listId: this._id }, { sort: { createdAt: -1 } });                                   // 73
    }                                                                                                                //
                                                                                                                     //
    return todos;                                                                                                    //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","meteor/underscore","./lists.js",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/lists/methods.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
exports.remove = exports.updateName = exports.makePublic = exports.makePrivate = exports.insert = undefined;         //
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _mdgValidatedMethod = require('meteor/mdg:validated-method');                                                    // 2
                                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                    // 3
                                                                                                                     //
var _ddpRateLimiter = require('meteor/ddp-rate-limiter');                                                            // 4
                                                                                                                     //
var _underscore = require('meteor/underscore');                                                                      // 5
                                                                                                                     //
var _lists = require('./lists.js');                                                                                  // 7
                                                                                                                     //
var LIST_ID_ONLY = new _aldeedSimpleSchema.SimpleSchema({                                                            // 9
  listId: { type: String }                                                                                           // 10
}).validator();                                                                                                      //
                                                                                                                     //
var insert = exports.insert = new _mdgValidatedMethod.ValidatedMethod({                                              // 13
  name: 'lists.insert',                                                                                              // 14
  validate: new _aldeedSimpleSchema.SimpleSchema({}).validator(),                                                    // 15
  run: function () {                                                                                                 // 16
    function run() {                                                                                                 //
      return _lists.Lists.insert({});                                                                                // 17
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var makePrivate = exports.makePrivate = new _mdgValidatedMethod.ValidatedMethod({                                    // 21
  name: 'lists.makePrivate',                                                                                         // 22
  validate: LIST_ID_ONLY,                                                                                            // 23
  run: function () {                                                                                                 // 24
    function run(_ref) {                                                                                             //
      var listId = _ref.listId;                                                                                      //
                                                                                                                     //
      if (!this.userId) {                                                                                            // 25
        throw new _meteor.Meteor.Error('lists.makePrivate.notLoggedIn', 'Must be logged in to make private lists.');
      }                                                                                                              //
                                                                                                                     //
      var list = _lists.Lists.findOne(listId);                                                                       // 30
                                                                                                                     //
      if (list.isLastPublicList()) {                                                                                 // 32
        throw new _meteor.Meteor.Error('lists.makePrivate.lastPublicList', 'Cannot make the last public list private.');
      }                                                                                                              //
                                                                                                                     //
      _lists.Lists.update(listId, {                                                                                  // 37
        $set: { userId: this.userId }                                                                                // 38
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var makePublic = exports.makePublic = new _mdgValidatedMethod.ValidatedMethod({                                      // 43
  name: 'lists.makePublic',                                                                                          // 44
  validate: LIST_ID_ONLY,                                                                                            // 45
  run: function () {                                                                                                 // 46
    function run(_ref2) {                                                                                            //
      var listId = _ref2.listId;                                                                                     //
                                                                                                                     //
      if (!this.userId) {                                                                                            // 47
        throw new _meteor.Meteor.Error('lists.makePublic.notLoggedIn', 'Must be logged in.');                        // 48
      }                                                                                                              //
                                                                                                                     //
      var list = _lists.Lists.findOne(listId);                                                                       // 52
                                                                                                                     //
      if (!list.editableBy(this.userId)) {                                                                           // 54
        throw new _meteor.Meteor.Error('lists.makePublic.accessDenied', 'You don\'t have permission to edit this list.');
      }                                                                                                              //
                                                                                                                     //
      // XXX the security check above is not atomic, so in theory a race condition could                             //
      // result in exposing private data                                                                             //
      _lists.Lists.update(listId, {                                                                                  // 46
        $unset: { userId: true }                                                                                     // 62
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var updateName = exports.updateName = new _mdgValidatedMethod.ValidatedMethod({                                      // 67
  name: 'lists.updateName',                                                                                          // 68
  validate: new _aldeedSimpleSchema.SimpleSchema({                                                                   // 69
    listId: { type: String },                                                                                        // 70
    newName: { type: String }                                                                                        // 71
  }).validator(),                                                                                                    //
  run: function () {                                                                                                 // 73
    function run(_ref3) {                                                                                            //
      var listId = _ref3.listId;                                                                                     //
      var newName = _ref3.newName;                                                                                   //
                                                                                                                     //
      var list = _lists.Lists.findOne(listId);                                                                       // 74
                                                                                                                     //
      if (!list.editableBy(this.userId)) {                                                                           // 76
        throw new _meteor.Meteor.Error('lists.updateName.accessDenied', 'You don\'t have permission to edit this list.');
      }                                                                                                              //
                                                                                                                     //
      // XXX the security check above is not atomic, so in theory a race condition could                             //
      // result in exposing private data                                                                             //
                                                                                                                     //
      _lists.Lists.update(listId, {                                                                                  // 73
        $set: { name: newName }                                                                                      // 85
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var remove = exports.remove = new _mdgValidatedMethod.ValidatedMethod({                                              // 90
  name: 'lists.remove',                                                                                              // 91
  validate: LIST_ID_ONLY,                                                                                            // 92
  run: function () {                                                                                                 // 93
    function run(_ref4) {                                                                                            //
      var listId = _ref4.listId;                                                                                     //
                                                                                                                     //
      var list = _lists.Lists.findOne(listId);                                                                       // 94
                                                                                                                     //
      if (!list.editableBy(this.userId)) {                                                                           // 96
        throw new _meteor.Meteor.Error('lists.remove.accessDenied', 'You don\'t have permission to remove this list.');
      }                                                                                                              //
                                                                                                                     //
      // XXX the security check above is not atomic, so in theory a race condition could                             //
      // result in exposing private data                                                                             //
                                                                                                                     //
      if (list.isLastPublicList()) {                                                                                 // 93
        throw new _meteor.Meteor.Error('lists.remove.lastPublicList', 'Cannot delete the last public list.');        // 105
      }                                                                                                              //
                                                                                                                     //
      _lists.Lists.remove(listId);                                                                                   // 109
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
// Get list of all method names on Lists                                                                             //
var LISTS_METHODS = _underscore._.pluck([insert, makePublic, makePrivate, updateName, remove], 'name');              // 114
                                                                                                                     //
if (_meteor.Meteor.isServer) {                                                                                       // 122
  // Only allow 5 list operations per connection per second                                                          //
  _ddpRateLimiter.DDPRateLimiter.addRule({                                                                           // 124
    name: function () {                                                                                              // 125
      function name(_name) {                                                                                         //
        return _underscore._.contains(LISTS_METHODS, _name);                                                         // 126
      }                                                                                                              //
                                                                                                                     //
      return name;                                                                                                   //
    }(),                                                                                                             //
                                                                                                                     //
                                                                                                                     //
    // Rate limit per connection ID                                                                                  //
    connectionId: function () {                                                                                      // 130
      function connectionId() {                                                                                      //
        return true;                                                                                                 // 130
      }                                                                                                              //
                                                                                                                     //
      return connectionId;                                                                                           //
    }()                                                                                                              //
  }, 5, 1000);                                                                                                       //
}                                                                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"todos":{"server":{"publications.js":["meteor/meteor","meteor/aldeed:simple-schema","../todos.js","../../lists/lists.js",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/todos/server/publications.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 3
                                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                    // 4
                                                                                                                     //
var _todos = require('../todos.js');                                                                                 // 6
                                                                                                                     //
var _lists = require('../../lists/lists.js');                                                                        // 7
                                                                                                                     //
/* eslint-disable prefer-arrow-callback */                                                                           //
                                                                                                                     //
_meteor.Meteor.publishComposite('todos.inList', function () {                                                        // 9
  function todosInList(listId) {                                                                                     // 9
    new _aldeedSimpleSchema.SimpleSchema({                                                                           // 10
      listId: { type: String }                                                                                       // 11
    }).validate({ listId: listId });                                                                                 //
                                                                                                                     //
    var userId = this.userId;                                                                                        // 14
                                                                                                                     //
    return {                                                                                                         // 16
      find: function () {                                                                                            // 17
        function find() {                                                                                            //
          var query = {                                                                                              // 18
            _id: listId,                                                                                             // 19
            $or: [{ userId: { $exists: false } }, { userId: userId }]                                                // 20
          };                                                                                                         //
                                                                                                                     //
          // We only need the _id field in this query, since it's only                                               //
          // used to drive the child queries to get the todos                                                        //
          var options = {                                                                                            // 17
            fields: { _id: 1 }                                                                                       // 26
          };                                                                                                         //
                                                                                                                     //
          return _lists.Lists.find(query, options);                                                                  // 29
        }                                                                                                            //
                                                                                                                     //
        return find;                                                                                                 //
      }(),                                                                                                           //
                                                                                                                     //
                                                                                                                     //
      children: [{                                                                                                   // 32
        find: function () {                                                                                          // 33
          function find(list) {                                                                                      //
            return _todos.Todos.find({ listId: list._id }, { fields: _todos.Todos.publicFields });                   // 34
          }                                                                                                          //
                                                                                                                     //
          return find;                                                                                               //
        }()                                                                                                          //
      }]                                                                                                             //
    };                                                                                                               //
  }                                                                                                                  //
                                                                                                                     //
  return todosInList;                                                                                                //
}());                                                                                                                //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"incompleteCountDenormalizer.js":["meteor/underscore","meteor/check","./todos.js","../lists/lists.js",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/todos/incompleteCountDenormalizer.js                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
                                                                                                                     //
var _underscore = require('meteor/underscore');                                                                      // 1
                                                                                                                     //
var _check = require('meteor/check');                                                                                // 2
                                                                                                                     //
var _todos = require('./todos.js');                                                                                  // 4
                                                                                                                     //
var _lists = require('../lists/lists.js');                                                                           // 5
                                                                                                                     //
var incompleteCountDenormalizer = {                                                                                  // 7
  _updateList: function () {                                                                                         // 8
    function _updateList(listId) {                                                                                   //
      // Recalculate the correct incomplete count direct from MongoDB                                                //
      var incompleteCount = _todos.Todos.find({                                                                      // 10
        listId: listId,                                                                                              // 11
        checked: false                                                                                               // 12
      }).count();                                                                                                    //
                                                                                                                     //
      _lists.Lists.update(listId, { $set: { incompleteCount: incompleteCount } });                                   // 15
    }                                                                                                                //
                                                                                                                     //
    return _updateList;                                                                                              //
  }(),                                                                                                               //
  afterInsertTodo: function () {                                                                                     // 17
    function afterInsertTodo(todo) {                                                                                 //
      this._updateList(todo.listId);                                                                                 // 18
    }                                                                                                                //
                                                                                                                     //
    return afterInsertTodo;                                                                                          //
  }(),                                                                                                               //
  afterUpdateTodo: function () {                                                                                     // 20
    function afterUpdateTodo(selector, modifier) {                                                                   //
      var _this = this;                                                                                              //
                                                                                                                     //
      // We only support very limited operations on todos                                                            //
      (0, _check.check)(modifier, { $set: Object });                                                                 // 22
                                                                                                                     //
      // We can only deal with $set modifiers, but that's all we do in this app                                      //
      if (_underscore._.has(modifier.$set, 'checked')) {                                                             // 20
        _todos.Todos.find(selector, { fields: { listId: 1 } }).forEach(function (todo) {                             // 26
          _this._updateList(todo.listId);                                                                            // 27
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                //
                                                                                                                     //
    return afterUpdateTodo;                                                                                          //
  }(),                                                                                                               //
                                                                                                                     //
  // Here we need to take the list of todos being removed, selected *before* the update                              //
  // because otherwise we can't figure out the relevant list id(s) (if the todo has been deleted)                    //
  afterRemoveTodos: function () {                                                                                    // 33
    function afterRemoveTodos(todos) {                                                                               //
      var _this2 = this;                                                                                             //
                                                                                                                     //
      todos.forEach(function (todo) {                                                                                // 34
        return _this2._updateList(todo.listId);                                                                      //
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return afterRemoveTodos;                                                                                         //
  }()                                                                                                                //
};                                                                                                                   //
                                                                                                                     //
exports['default'] = incompleteCountDenormalizer;                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/underscore","meteor/mdg:validated-method","meteor/aldeed:simple-schema","meteor/ddp-rate-limiter","./todos.js","../lists/lists.js",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/todos/methods.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
exports.remove = exports.updateText = exports.setCheckedStatus = exports.insert = undefined;                         //
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _underscore = require('meteor/underscore');                                                                      // 2
                                                                                                                     //
var _mdgValidatedMethod = require('meteor/mdg:validated-method');                                                    // 3
                                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                    // 4
                                                                                                                     //
var _ddpRateLimiter = require('meteor/ddp-rate-limiter');                                                            // 5
                                                                                                                     //
var _todos = require('./todos.js');                                                                                  // 7
                                                                                                                     //
var _lists = require('../lists/lists.js');                                                                           // 8
                                                                                                                     //
var insert = exports.insert = new _mdgValidatedMethod.ValidatedMethod({                                              // 10
  name: 'todos.insert',                                                                                              // 11
  validate: new _aldeedSimpleSchema.SimpleSchema({                                                                   // 12
    listId: { type: String },                                                                                        // 13
    text: { type: String }                                                                                           // 14
  }).validator(),                                                                                                    //
  run: function () {                                                                                                 // 16
    function run(_ref) {                                                                                             //
      var listId = _ref.listId;                                                                                      //
      var text = _ref.text;                                                                                          //
                                                                                                                     //
      var list = _lists.Lists.findOne(listId);                                                                       // 17
                                                                                                                     //
      if (list.isPrivate() && list.userId !== this.userId) {                                                         // 19
        throw new _meteor.Meteor.Error('todos.insert.accessDenied', 'Cannot add todos to a private list that is not yours');
      }                                                                                                              //
                                                                                                                     //
      var todo = {                                                                                                   // 24
        listId: listId,                                                                                              // 25
        text: text,                                                                                                  // 26
        checked: false,                                                                                              // 27
        createdAt: new Date()                                                                                        // 28
      };                                                                                                             //
                                                                                                                     //
      _todos.Todos.insert(todo);                                                                                     // 31
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var setCheckedStatus = exports.setCheckedStatus = new _mdgValidatedMethod.ValidatedMethod({                          // 35
  name: 'todos.makeChecked',                                                                                         // 36
  validate: new _aldeedSimpleSchema.SimpleSchema({                                                                   // 37
    todoId: { type: String },                                                                                        // 38
    newCheckedStatus: { type: Boolean }                                                                              // 39
  }).validator(),                                                                                                    //
  run: function () {                                                                                                 // 41
    function run(_ref2) {                                                                                            //
      var todoId = _ref2.todoId;                                                                                     //
      var newCheckedStatus = _ref2.newCheckedStatus;                                                                 //
                                                                                                                     //
      var todo = _todos.Todos.findOne(todoId);                                                                       // 42
                                                                                                                     //
      if (todo.checked === newCheckedStatus) {                                                                       // 44
        // The status is already what we want, let's not do any extra work                                           //
        return;                                                                                                      // 46
      }                                                                                                              //
                                                                                                                     //
      if (!todo.editableBy(this.userId)) {                                                                           // 49
        throw new _meteor.Meteor.Error('todos.setCheckedStatus.accessDenied', 'Cannot edit checked status in a private list that is not yours');
      }                                                                                                              //
                                                                                                                     //
      _todos.Todos.update(todoId, { $set: {                                                                          // 54
          checked: newCheckedStatus                                                                                  // 55
        } });                                                                                                        //
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var updateText = exports.updateText = new _mdgValidatedMethod.ValidatedMethod({                                      // 60
  name: 'todos.updateText',                                                                                          // 61
  validate: new _aldeedSimpleSchema.SimpleSchema({                                                                   // 62
    todoId: { type: String },                                                                                        // 63
    newText: { type: String }                                                                                        // 64
  }).validator(),                                                                                                    //
  run: function () {                                                                                                 // 66
    function run(_ref3) {                                                                                            //
      var todoId = _ref3.todoId;                                                                                     //
      var newText = _ref3.newText;                                                                                   //
                                                                                                                     //
      // This is complex auth stuff - perhaps denormalizing a userId onto todos                                      //
      // would be correct here?                                                                                      //
      var todo = _todos.Todos.findOne(todoId);                                                                       // 69
                                                                                                                     //
      if (!todo.editableBy(this.userId)) {                                                                           // 71
        throw new _meteor.Meteor.Error('todos.updateText.accessDenied', 'Cannot edit todos in a private list that is not yours');
      }                                                                                                              //
                                                                                                                     //
      _todos.Todos.update(todoId, {                                                                                  // 76
        $set: { text: newText }                                                                                      // 77
      });                                                                                                            //
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
var remove = exports.remove = new _mdgValidatedMethod.ValidatedMethod({                                              // 82
  name: 'todos.remove',                                                                                              // 83
  validate: new _aldeedSimpleSchema.SimpleSchema({                                                                   // 84
    todoId: { type: String }                                                                                         // 85
  }).validator(),                                                                                                    //
  run: function () {                                                                                                 // 87
    function run(_ref4) {                                                                                            //
      var todoId = _ref4.todoId;                                                                                     //
                                                                                                                     //
      var todo = _todos.Todos.findOne(todoId);                                                                       // 88
                                                                                                                     //
      if (!todo.editableBy(this.userId)) {                                                                           // 90
        throw new _meteor.Meteor.Error('todos.remove.accessDenied', 'Cannot remove todos in a private list that is not yours');
      }                                                                                                              //
                                                                                                                     //
      _todos.Todos.remove(todoId);                                                                                   // 95
    }                                                                                                                //
                                                                                                                     //
    return run;                                                                                                      //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
// Get list of all method names on Todos                                                                             //
var TODOS_METHODS = _underscore._.pluck([insert, setCheckedStatus, updateText, remove], 'name');                     // 100
                                                                                                                     //
if (_meteor.Meteor.isServer) {                                                                                       // 107
  // Only allow 5 todos operations per connection per second                                                         //
  _ddpRateLimiter.DDPRateLimiter.addRule({                                                                           // 109
    name: function () {                                                                                              // 110
      function name(_name) {                                                                                         //
        return _underscore._.contains(TODOS_METHODS, _name);                                                         // 111
      }                                                                                                              //
                                                                                                                     //
      return name;                                                                                                   //
    }(),                                                                                                             //
                                                                                                                     //
                                                                                                                     //
    // Rate limit per connection ID                                                                                  //
    connectionId: function () {                                                                                      // 115
      function connectionId() {                                                                                      //
        return true;                                                                                                 // 115
      }                                                                                                              //
                                                                                                                     //
      return connectionId;                                                                                           //
    }()                                                                                                              //
  }, 5, 1000);                                                                                                       //
}                                                                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"todos.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/mongo","meteor/factory","faker","./incompleteCountDenormalizer.js","meteor/aldeed:simple-schema","../lists/lists.js",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/todos/todos.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
exports.__esModule = true;                                                                                           //
exports.Todos = undefined;                                                                                           //
                                                                                                                     //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                              //
                                                                                                                     //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                     //
                                                                                                                     //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                        //
                                                                                                                     //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                               //
                                                                                                                     //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                          //
                                                                                                                     //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                 //
                                                                                                                     //
var _mongo = require('meteor/mongo');                                                                                // 1
                                                                                                                     //
var _factory = require('meteor/factory');                                                                            // 2
                                                                                                                     //
var _faker = require('faker');                                                                                       // 3
                                                                                                                     //
var _faker2 = _interopRequireDefault(_faker);                                                                        //
                                                                                                                     //
var _incompleteCountDenormalizer = require('./incompleteCountDenormalizer.js');                                      // 5
                                                                                                                     //
var _incompleteCountDenormalizer2 = _interopRequireDefault(_incompleteCountDenormalizer);                            //
                                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                    // 6
                                                                                                                     //
var _lists = require('../lists/lists.js');                                                                           // 7
                                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                    //
                                                                                                                     //
var TodosCollection = function (_Mongo$Collection) {                                                                 //
  (0, _inherits3['default'])(TodosCollection, _Mongo$Collection);                                                    //
                                                                                                                     //
  function TodosCollection() {                                                                                       //
    (0, _classCallCheck3['default'])(this, TodosCollection);                                                         //
    return (0, _possibleConstructorReturn3['default'])(this, _Mongo$Collection.apply(this, arguments));              //
  }                                                                                                                  //
                                                                                                                     //
  TodosCollection.prototype.insert = function () {                                                                   //
    function insert(doc, callback) {                                                                                 //
      var ourDoc = doc;                                                                                              // 11
      ourDoc.createdAt = ourDoc.createdAt || new Date();                                                             // 12
      var result = _Mongo$Collection.prototype.insert.call(this, ourDoc, callback);                                  // 13
      _incompleteCountDenormalizer2['default'].afterInsertTodo(ourDoc);                                              // 14
      return result;                                                                                                 // 15
    }                                                                                                                //
                                                                                                                     //
    return insert;                                                                                                   //
  }();                                                                                                               //
                                                                                                                     //
  TodosCollection.prototype.update = function () {                                                                   // 9
    function update(selector, modifier) {                                                                            //
      var result = _Mongo$Collection.prototype.update.call(this, selector, modifier);                                // 18
      _incompleteCountDenormalizer2['default'].afterUpdateTodo(selector, modifier);                                  // 19
      return result;                                                                                                 // 20
    }                                                                                                                //
                                                                                                                     //
    return update;                                                                                                   //
  }();                                                                                                               //
                                                                                                                     //
  TodosCollection.prototype.remove = function () {                                                                   // 9
    function remove(selector) {                                                                                      //
      var todos = this.find(selector).fetch();                                                                       // 23
      var result = _Mongo$Collection.prototype.remove.call(this, selector);                                          // 24
      _incompleteCountDenormalizer2['default'].afterRemoveTodos(todos);                                              // 25
      return result;                                                                                                 // 26
    }                                                                                                                //
                                                                                                                     //
    return remove;                                                                                                   //
  }();                                                                                                               //
                                                                                                                     //
  return TodosCollection;                                                                                            //
}(_mongo.Mongo.Collection);                                                                                          //
                                                                                                                     //
var Todos = exports.Todos = new TodosCollection('Todos');                                                            // 30
                                                                                                                     //
// Deny all client-side updates since we will be using methods to manage this collection                             //
Todos.deny({                                                                                                         // 33
  insert: function () {                                                                                              // 34
    function insert() {                                                                                              //
      return true;                                                                                                   // 34
    }                                                                                                                //
                                                                                                                     //
    return insert;                                                                                                   //
  }(),                                                                                                               //
  update: function () {                                                                                              // 35
    function update() {                                                                                              //
      return true;                                                                                                   // 35
    }                                                                                                                //
                                                                                                                     //
    return update;                                                                                                   //
  }(),                                                                                                               //
  remove: function () {                                                                                              // 36
    function remove() {                                                                                              //
      return true;                                                                                                   // 36
    }                                                                                                                //
                                                                                                                     //
    return remove;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Todos.schema = new _aldeedSimpleSchema.SimpleSchema({                                                                // 39
  listId: {                                                                                                          // 40
    type: String,                                                                                                    // 41
    regEx: _aldeedSimpleSchema.SimpleSchema.RegEx.Id,                                                                // 42
    denyUpdate: true                                                                                                 // 43
  },                                                                                                                 //
  text: {                                                                                                            // 45
    type: String,                                                                                                    // 46
    max: 100                                                                                                         // 47
  },                                                                                                                 //
  createdAt: {                                                                                                       // 49
    type: Date,                                                                                                      // 50
    denyUpdate: true                                                                                                 // 51
  },                                                                                                                 //
  checked: {                                                                                                         // 53
    type: Boolean,                                                                                                   // 54
    defaultValue: false                                                                                              // 55
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
Todos.attachSchema(Todos.schema);                                                                                    // 59
                                                                                                                     //
// This represents the keys from Lists objects that should be published                                              //
// to the client. If we add secret properties to List objects, don't list                                            //
// them here to keep them private to the server.                                                                     //
Todos.publicFields = {                                                                                               // 64
  listId: 1,                                                                                                         // 65
  text: 1,                                                                                                           // 66
  createdAt: 1,                                                                                                      // 67
  checked: 1                                                                                                         // 68
};                                                                                                                   //
                                                                                                                     //
// TODO This factory has a name - do we have a code style for this?                                                  //
//   - usually I've used the singular, sometimes you have more than one though, like                                 //
//   'todo', 'emptyTodo', 'checkedTodo'                                                                              //
_factory.Factory.define('todo', Todos, {                                                                             // 74
  listId: function () {                                                                                              // 75
    function listId() {                                                                                              // 75
      return _factory.Factory.get('list');                                                                           //
    }                                                                                                                //
                                                                                                                     //
    return listId;                                                                                                   //
  }(),                                                                                                               //
  text: function () {                                                                                                // 76
    function text() {                                                                                                // 76
      return _faker2['default'].lorem.sentence();                                                                    //
    }                                                                                                                //
                                                                                                                     //
    return text;                                                                                                     //
  }(),                                                                                                               //
  createdAt: function () {                                                                                           // 77
    function createdAt() {                                                                                           // 77
      return new Date();                                                                                             //
    }                                                                                                                //
                                                                                                                     //
    return createdAt;                                                                                                //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
Todos.helpers({                                                                                                      // 80
  list: function () {                                                                                                // 81
    function list() {                                                                                                //
      return _lists.Lists.findOne(this.listId);                                                                      // 82
    }                                                                                                                //
                                                                                                                     //
    return list;                                                                                                     //
  }(),                                                                                                               //
  editableBy: function () {                                                                                          // 84
    function editableBy(userId) {                                                                                    //
      return this.list().editableBy(userId);                                                                         // 85
    }                                                                                                                //
                                                                                                                     //
    return editableBy;                                                                                               //
  }()                                                                                                                //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"fixtures.js":["meteor/meteor","../../api/lists/lists.js","../../api/todos/todos.js",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/fixtures.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _lists = require('../../api/lists/lists.js');                                                                    // 2
                                                                                                                     //
var _todos = require('../../api/todos/todos.js');                                                                    // 3
                                                                                                                     //
// if the database is empty on server start, create some sample data.                                                //
_meteor.Meteor.startup(function () {                                                                                 // 6
  if (_lists.Lists.find().count() === 0) {                                                                           // 7
    (function () {                                                                                                   //
      var data = [{                                                                                                  // 8
        name: 'Meteor Principles',                                                                                   // 10
        items: ['Data on the Wire', 'One Language', 'Database Everywhere', 'Latency Compensation', 'Full Stack Reactivity', 'Embrace the Ecosystem', 'Simplicity Equals Productivity']
      }, {                                                                                                           //
        name: 'Languages',                                                                                           // 22
        items: ['Lisp', 'C', 'C++', 'Python', 'Ruby', 'JavaScript', 'Scala', 'Erlang', '6502 Assembly']              // 23
      }, {                                                                                                           //
        name: 'Favorite Scientists',                                                                                 // 36
        items: ['Ada Lovelace', 'Grace Hopper', 'Marie Curie', 'Carl Friedrich Gauss', 'Nikola Tesla', 'Claude Shannon']
      }];                                                                                                            //
                                                                                                                     //
      var timestamp = new Date().getTime();                                                                          // 48
                                                                                                                     //
      data.forEach(function (list) {                                                                                 // 50
        var listId = _lists.Lists.insert({                                                                           // 51
          name: list.name,                                                                                           // 52
          incompleteCount: list.items.length                                                                         // 53
        });                                                                                                          //
                                                                                                                     //
        list.items.forEach(function (text) {                                                                         // 56
          _todos.Todos.insert({                                                                                      // 57
            listId: listId,                                                                                          // 58
            text: text,                                                                                              // 59
            createdAt: new Date(timestamp)                                                                           // 60
          });                                                                                                        //
                                                                                                                     //
          timestamp += 1; // ensure unique timestamp.                                                                // 63
        });                                                                                                          // 56
      });                                                                                                            //
    })();                                                                                                            //
  }                                                                                                                  //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./fixtures.js","./reset-password-email.js","./security.js","./register-api.js",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/index.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
require('./fixtures.js');                                                                                            // 2
                                                                                                                     //
require('./reset-password-email.js');                                                                                // 5
                                                                                                                     //
require('./security.js');                                                                                            // 8
                                                                                                                     //
require('./register-api.js');                                                                                        // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/lists/methods.js","../../api/lists/server/publications.js","../../api/todos/methods.js","../../api/todos/server/publications.js",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/register-api.js                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
require('../../api/lists/methods.js');                                                                               // 1
                                                                                                                     //
require('../../api/lists/server/publications.js');                                                                   // 2
                                                                                                                     //
require('../../api/todos/methods.js');                                                                               // 3
                                                                                                                     //
require('../../api/todos/server/publications.js');                                                                   // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"reset-password-email.js":["meteor/accounts-base",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/reset-password-email.js                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _accountsBase = require('meteor/accounts-base');                                                                 // 1
                                                                                                                     //
_accountsBase.Accounts.emailTemplates.siteName = 'Meteor Guide Todos Example';                                       // 4
_accountsBase.Accounts.emailTemplates.from = 'Meteor Todos Accounts <accounts@example.com>';                         // 5
                                                                                                                     //
_accountsBase.Accounts.emailTemplates.resetPassword = {                                                              // 7
  subject: function () {                                                                                             // 8
    function subject() {                                                                                             //
      return 'Reset your password on Meteor Todos';                                                                  // 9
    }                                                                                                                //
                                                                                                                     //
    return subject;                                                                                                  //
  }(),                                                                                                               //
  text: function () {                                                                                                // 11
    function text(user, url) {                                                                                       //
      return 'Hello!\n\nClick the link below to reset your password on Meteor Todos.\n\n' + url + '\n\nIf you didn\'t request this email, please ignore it.\n\nThanks,\nThe Meteor Todos team\n';
    }                                                                                                                //
                                                                                                                     //
    return text;                                                                                                     //
  }()                                                                                                                //
};                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"security.js":["meteor/meteor","meteor/ddp-rate-limiter","meteor/underscore",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/security.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _meteor = require('meteor/meteor');                                                                              // 1
                                                                                                                     //
var _ddpRateLimiter = require('meteor/ddp-rate-limiter');                                                            // 2
                                                                                                                     //
var _underscore = require('meteor/underscore');                                                                      // 3
                                                                                                                     //
// Don't let people write arbitrary data to their 'profile' field from the client                                    //
_meteor.Meteor.users.deny({                                                                                          // 6
  update: function () {                                                                                              // 7
    function update() {                                                                                              //
      return true;                                                                                                   // 8
    }                                                                                                                //
                                                                                                                     //
    return update;                                                                                                   //
  }()                                                                                                                //
});                                                                                                                  //
                                                                                                                     //
// Get a list of all accounts methods by running `Meteor.server.method_handlers` in meteor shell                     //
var AUTH_METHODS = ['login', 'logout', 'logoutOtherClients', 'getNewToken', 'removeOtherTokens', 'configureLoginService', 'changePassword', 'forgotPassword', 'resetPassword', 'verifyEmail', 'createUser', 'ATRemoveService', 'ATCreateUserServer', 'ATResendVerificationEmail'];
                                                                                                                     //
if (_meteor.Meteor.isServer) {                                                                                       // 30
  // Only allow 2 login attempts per connection per 5 seconds                                                        //
  _ddpRateLimiter.DDPRateLimiter.addRule({                                                                           // 32
    name: function () {                                                                                              // 33
      function name(_name) {                                                                                         //
        return _underscore._.contains(AUTH_METHODS, _name);                                                          // 34
      }                                                                                                              //
                                                                                                                     //
      return name;                                                                                                   //
    }(),                                                                                                             //
                                                                                                                     //
                                                                                                                     //
    // Rate limit per connection ID                                                                                  //
    connectionId: function () {                                                                                      // 38
      function connectionId() {                                                                                      //
        return true;                                                                                                 // 38
      }                                                                                                              //
                                                                                                                     //
      return connectionId;                                                                                           //
    }()                                                                                                              //
  }, 2, 5000);                                                                                                       //
}                                                                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"i18n":{"en.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// i18n/en.i18n.json                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"lists":{"makePrivate":{"notLoggedIn":"Must be logged in to make private lists.","lastPublicList":"Cannot make the last public list private."},"makePublic":{"notLoggedIn":"Must be logged in.","accessDenied":"You don't have permission to edit this list."},"updateName":{"accessDenied":"You don't have permission to edit this list."},"remove":{"accessDenied":"'You don't have permission to remove this list.'","lastPublicList":"Cannot delete the last public list."}},"todos":{"insert":{"accessDenied":"Cannot add todos to a private list that is not yours"},"setCheckedStatus":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"updateText":{"accessDenied":"Cannot edit todos in a private list that is not yours"},"remove":{"accessDenied":"Cannot remove todos in a private list that is not yours"}}};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["/imports/startup/server",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
require('/imports/startup/server');                                                                                  // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./i18n/en.i18n.json");
require("./server/main.js");
//# sourceMappingURL=app.js.map
